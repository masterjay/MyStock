#!/bin/bash
cd /home/s0971417/taiwan-stock-monitor-complete/backend
source venv/bin/activate
python3 run_daily.py
