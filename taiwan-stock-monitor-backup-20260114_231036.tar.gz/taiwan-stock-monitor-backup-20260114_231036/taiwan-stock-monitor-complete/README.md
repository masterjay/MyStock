# 台股監控系統 - Taiwan Market Pulse

完整的台股融資水位與台指期多空比監控系統

## 📁 專案結構

```
.
├── backend/                    # 後端數據爬蟲
│   ├── scraper_twse.py        # 證交所融資數據爬蟲
│   ├── scraper_taifex.py      # 期交所期貨數據爬蟲
│   ├── data_collector.py      # 主數據收集器
│   ├── requirements.txt       # Python 依賴套件
│   └── market_data.db         # SQLite 數據庫 (自動生成)
│
├── frontend/                   # 前端介面
│   ├── index.html             # 獨立 HTML 版本 (可直接開啟)
│   └── TaiwanStockDashboard.jsx  # React 組件
│
└── data/                       # 數據輸出目錄
    └── market_data.json       # JSON 格式數據 (供前端讀取)
```

## 🚀 快速開始

### 方法一: 只看前端 (最簡單)

1. 直接用瀏覽器開啟 `frontend/index.html`
2. 會顯示模擬數據的 Dashboard

### 方法二: 完整版 (含數據爬取)

#### Step 1: 安裝 Python 依賴

```bash
cd backend
pip install -r requirements.txt
```

#### Step 2: 執行數據收集

```bash
python data_collector.py
```

這會:
- 爬取最新的融資與期貨數據
- 存入 SQLite 數據庫
- 產生 `data/market_data.json`

#### Step 3: 查看 Dashboard

用瀏覽器開啟 `frontend/index.html`，會自動載入真實數據

## 📊 功能說明

### 1. 融資使用率監控
- **數據來源**: 證交所信用交易統計
- **計算方式**: 融資餘額 / 市值
- **警戒水位**:
  - 🔴 ≥28%: 高水位 (融資過熱)
  - 🟠 25-28%: 偏高
  - 🟢 20-25%: 正常
  - 🔵 <20%: 偏低

### 2. 台指期多空比
- **數據來源**: 期交所三大法人留倉部位
- **計算方式**: 多單 / 空單
- **市場情緒**:
  - 🟢 ≥1.2: 偏多
  - 🟡 0.8-1.2: 平衡
  - 🔴 <0.8: 偏空

### 3. 歷史趨勢圖
- 30 日融資使用率走勢
- 30 日多空比走勢
- 外資淨部位變化

## 🔧 進階配置

### 自動定時更新

編輯 `backend/data_collector.py`，取消最後一行註解:

```python
if __name__ == "__main__":
    collector = DataCollector()
    collector.collect_daily_data()
    collector.export_to_json()
    
    # 啟動定時任務 (每天下午 3:30 執行)
    run_scheduler()  # 取消這行註解
```

### 修改更新時間

在 `data_collector.py` 的 `run_scheduler()` 函數中修改:

```python
# 改成你想要的時間
schedule.every().day.at("15:30").do(collector.collect_daily_data)
```

## 🌐 部署方案

### 選項 1: 本地使用
- 直接執行 Python 腳本 + 開啟 HTML
- 適合個人使用

### 選項 2: Vercel (前端) + PythonAnywhere (後端)

**前端 (Vercel)**:
```bash
cd frontend
vercel deploy
```

**後端 (PythonAnywhere)**:
1. 註冊免費帳號
2. 上傳 backend 資料夾
3. 設定定時任務執行 data_collector.py
4. 將產生的 JSON 複製到前端

### 選項 3: 全部用 Railway
1. 建立 Railway 專案
2. 連接 GitHub repository
3. Railway 會自動部署

## 📝 數據來源 API

### 證交所
- 融資融券: `https://www.twse.com.tw/rwd/zh/marginTrade/MI_MARGN`
- 市值資料: `https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX`

### 期交所
- 未平倉量: `https://www.taifex.com.tw/cht/3/futContractsDateDown`
- 三大法人: `https://www.taifex.com.tw/cht/3/futContractsDate`

## ⚠️ 注意事項

1. **交易日限制**: 只有交易日才有數據，假日會拿不到
2. **更新時間**: 建議在下午 3:30 後執行 (盤後結算完成)
3. **請求頻率**: 爬蟲間隔 3 秒，避免被擋
4. **資料準確性**: 官方數據可能有延遲，僅供參考

## 🛠️ 常見問題

**Q: 為什麼抓不到數據?**
- 確認今天是交易日
- 檢查網路連線
- 可能是官方網站維護

**Q: 如何查看歷史數據?**
- 數據存在 `market_data.db`
- 可用 SQLite 瀏覽器查看

**Q: 可以加入其他指標嗎?**
- 可以! 參考 scraper 的寫法
- 加入新的數據源和欄位

## 📈 使用建議

這個系統提供的是**市場情緒指標**,不是進出場訊號:

- **融資高水位 (>28%)**: 市場過熱,注意回檔風險
- **融資低水位 (<20%)**: 市場冷清,可能接近底部
- **外資大幅做多**: 通常看好後市
- **多空比極端值**: 可能是反轉訊號

**記住**: 這些是輔助指標,要搭配其他技術/基本面分析!

## 📧 聯絡 & 改進

有任何問題或建議,歡迎提出!

---

**免責聲明**: 本系統僅供學習與參考,不構成投資建議。投資有風險,請自行判斷。
